<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['title'] = 'ABC dot COM';

$config['panel_color'] = 'panel-primary';
