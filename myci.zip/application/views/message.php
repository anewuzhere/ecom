<html>
<head>
<title></title>
</head>
<body>
    <h2> Welcome to View </h2>
    <?= $message ?>
</body>
</html>