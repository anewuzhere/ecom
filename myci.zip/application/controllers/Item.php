<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Item extends CI_Controller {
    public function __construct()
    {
            parent::__construct();
            // Your own constructor code
            //$this->load->config('myconfig');
    }

    public function test(){
        //$this->config->set_item('title','My New title');
        //echo $this->config->item('title');
        echo $this->config->base_url();
        echo '<br/>';
        echo $this->config->site_url();
        echo '<br/>';
        echo $this->config->system_url();
        echo '<br/>';
        echo base_url();

    }

    public function test2(){
        echo 'first segment: '.$this->uri->segment(1);
        echo '<br/>';
        echo 'second segment: '.$this->uri->segment(2);
        echo '<br/>';
        echo 'third segment: '.$this->uri->segment(3);
        echo '<br/>';

    }
    public function test3($x, $y, $z){
        echo 'first value: '.$x;
        echo '<br/>';
        echo 'second value: '.$y;
        echo '<br/>';
        echo 'third value: '.$z;
        echo '<br/>';

    }


    public function index(){
        $this->load->config('myconfig');
        $data['items'] = ["apple","orange","mango","banana"];
        $data['panel_color'] = $this->config->item('panel_color');
        $this->load->view('item/index',$data);

    }


    public function message(){
        $data['message'] = 'Welcome to CI';
        $this->load->view('message',$data);
    }

    /*
    public function _remap($x){
        if($x=="test"){
            $this->index();
        } else if ($x=="hello"){
            echo 'Hello There';

        } else if ($x=="rmda"){
            $this->test();
        } else {
            echo 'default';

        }

    }
*/
    public function pnf(){
        echo 'Di makita ang page!';

    }

}