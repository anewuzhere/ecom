

<div class="header">
<div class="container">
   <div class="row">
      <div class="col-md-12">
         <!-- Logo -->
         <div class="logo">
         </div>
      </div>
   </div>
</div>
</div>
<br><br><br><br><br><br><br><br><br>
<div class="page-content container">
<div class="row">
<div class="col-md-4 col-md-offset-4">
 <div class="login-wrapper">
       <div class="box">
           <div class="content-wrap">
               <h6>Sign In</h6>
               <div class="social">
                     
                       <div class="division">
                          
                       </div>
                   </div>
               <input class="form-control" type="text" placeholder="E-mail address">
               <input class="form-control" type="password" placeholder="Password">
               <div class="action">
                   <a class="btn btn-primary signup" href="index.html">Login</a>
                   <br><br>
               </div>                
           </div>
       </div>

      
   </div>
</div>
</div>
</div>