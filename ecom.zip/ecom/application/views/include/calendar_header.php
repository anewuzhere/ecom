<html>
<head>
<title></title>
<link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">

    <!-- Bootstrap -->
    <link href="<?=base_url()?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?=base_url()?>vendor/fullcalendar/fullcalendar.css" rel="stylesheet" media="screen">
    <!-- styles -->
    <link href="<?=base_url()?>css/styles.css" rel="stylesheet">

    <link href="<?=base_url()?>css/calendar.css" rel="stylesheet">
    <html>


<link href="<?=base_url()?>bs/css/bootstrap.min.css" rel="stylesheet">

</head>
