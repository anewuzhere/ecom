 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
 <script src="https://code.jquery.com/jquery.js"></script>
    <!-- jQuery UI -->
    <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?=base_url()?>bootstrap/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="<?=base_url()?>vendor/morris/morris.css">


    <script src="<?=base_url()?>vendor/jquery.knob.js"></script>
    <script src="<?=base_url()?>vendor/raphael-min.js"></script>
    <script src="<?=base_url()?>vendor/morris/morris.min.js"></script>

    <script src="<?=base_url()?>vendor/flot/jquery.flot.js"></script>
    <script src="<?=base_url()?>vendor/flot/jquery.flot.categories.js"></script>
    <script src="<?=base_url()?>vendor/flot/jquery.flot.pie.js"></script>
    <script src="<?=base_url()?>vendor/flot/jquery.flot.time.js"></script>
    <script src="<?=base_url()?>vendor/flot/jquery.flot.stack.js"></script>
    <script src="<?=base_url()?>vendor/flot/jquery.flot.resize.js"></script>

    <script src="<?=base_url()?>js/custom.js"></script>
    <script src="<?=base_url()?>js/stats.js"></script>
</body>
</html>