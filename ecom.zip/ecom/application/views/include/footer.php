<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?=base_url()?>bs/js/bootstrap.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
     <!-- jQuery library -->
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="<?=base_url()?>js/bootstrap.js"></script>  
  <!-- SmartMenus jQuery plugin -->
  <script type="text/javascript" src="<?=base_url()?>js/jquery.smartmenus.js"></script>
  <!-- SmartMenus jQuery Bootstrap Addon -->
  <script type="text/javascript" src="<?=base_url()?>js/jquery.smartmenus.bootstrap.js"></script>  
  <!-- To Slider JS -->
  <script src="<?=base_url()?>js/sequence.js"></script>
  <script src="<?=base_url()?>js/sequence-theme.modern-slide-in.js"></script>  
  <!-- Product view slider -->
  <script type="text/javascript" src="<?=base_url()?>js/jquery.simpleGallery.js"></script>
  <script type="text/javascript" src="<?=base_url()?>js/jquery.simpleLens.js"></script>
  <!-- slick slider -->
  <script type="text/javascript" src="<?=base_url()?>js/slick.js"></script>
  <!-- Price picker slider -->
  <script type="text/javascript" src="<?=base_url()?>js/nouislider.js"></script>
  <!-- Custom js -->
  <script src="<?=base_url()?>js/custom.js"></script> 

</body>
</html>