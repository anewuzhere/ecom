<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
 <script src="https://code.jquery.com/jquery.js"></script>
 <!-- jQuery UI -->
 <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
 <!-- Include all compiled plugins (below), or include individual files as needed -->
 <script src="<?=base_url()?>bootstrap/js/bootstrap.min.js"></script>

 <script src="<?=base_url()?>vendor/fullcalendar/fullcalendar.js"></script>
 <script src="<?=base_url()?>vendor/fullcalendar/gcal.js"></script>
 <script src="<?=base_url()?>js/custom.js"></script>
 <script src="<?=base_url()?>js/calendar.js"></script>
 </body>
 </html>