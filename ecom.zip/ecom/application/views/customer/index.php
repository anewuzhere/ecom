<link rel="stylesheet" type="text/css" href="<?=base_url()?>css/a.css"/>
<div class = "container">                                                  <center>
  <br>
<div class="form-group">
  <label class="col-md-4 control-label" for="waybill">Waybill Number: </label>  
  <div class="col-md-4">
  <input id="waybill" name="waybill" type="text" placeholder="Waybill Number" class="form-control input-md">
    
  </div>
</div>
<br/><br/><br>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="equipment">Equipment:</label>
  <div class="col-md-4">
    <select id="equipment" name="equipment" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>
<br/><br/><br/>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="driver">Driver:</label>
  <div class="col-md-4">
    <select id="driver" name="driver" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>
<br/><br/>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="helper">Helper:</label>
  <div class="col-md-4">
    <select id="helper" name="helper" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>
<br/><br/>
<div class="form-group">
  <label class="col-md-4 control-label" for="helper">Date:</label>
  <div class="col-md-4">
    <input type="date" id="helper" name="helper" class="form-control">
     
    </select>
  </div>
</div>
<!-- Select Basic -->
<!-- <div class="input-group date" data-provide="datepicker">
    <input type="date" class="form-control">
    <div class="input-group-addon">
        <span class="glyphicon glyphicon-th"></span>
    </div>
   
</div> -->
<br/><br/>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="customertype">Customer Type</label>
  <div class="col-md-4">
    <select id="customertype" name="customertype" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>
<br/><br/>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="cargotype">Cargo Type:</label>
  <div class="col-md-4">
    <select id="cargotype" name="cargotype" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>
<br/><br/>
<!-- Select Basic -->
<div class="form-group">
  <label class="col-md-4 control-label" for="importer">Customer/ Importer:</label>
  <div class="col-md-4">
    <select id="importer" name="importer" class="form-control">
      <option value="1">Option one</option>
      <option value="2">Option two</option>
    </select>
  </div>
</div>
<br/><br/>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="destination">Destination:</label>  
  <div class="col-md-4">
  <input id="destination" name="destination" type="text" placeholder="Destination" class="form-control input-md">
  <br/><br/>
  </div>
</div>

<!-- Button (Double) -->
<div class="form-group">
  <label class="col-md-4 control-label" for=""></label>
  <div class="col-md-8">
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <button id="" name="" class="btn btn-success">Submit</button>
    <button id="" name="" class="btn btn-danger">Cancel</button>
  </div>
</div> 
</div></center>