<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Driver extends CI_Controller {
    public function __construct()
    {
            parent::__construct();
            $this->load->model('DriverModel');
    }
    
    
    public function index(){
        
        $items =  $this->DriverModel->view();
        $this->load->view('includes/header');
        $this->load->view('includes/header_nav');
        $this->load->view('staff/driver/index',compact('items'));
        $this->load->view('includes/footer');  
    }   
    

     
     public function view($id){
        $item = $this->DriverModel->getProd($id);
        $this->load->view('includes/header');
        $this->load->view('includes/header_nav');
        $this->load->view('staff/driver/view',compact('item'));
        $this->load->view('includes/footer');
    }
    public function add(){
        
        $this->load->view('includes/header');
        $this->load->view('includes/header_nav');
        $this->load->view('staff/driver/add' );
        $this->load->view('includes/footer');

    }
    public function edit($id){
        $item = $this->DriverModel->getProd($id);
        $this->load->view('includes/header');
        $this->load->view('includes/header_nav');
        $this->load->view('staff/driver/edit',compact('item'));
        $this->load->view('includes/footer');

    }
    public function delete($id){
        $item =$this->DriverModel->getProd($id);
        $this->load->view('includes/header');
        $this->load->view('includes/header_nav');
        $this->load->view('staff/driver/delete',compact('item'));
        $this->load->view('includes/footer');
    } 
    public function del($id){
      
        $data= $this->input->post();
        unset($data['delete']);
         $item =$this->uri->segment(4);
         $this->DriverModel->delete($id,$data);
         redirect('Driver/index');
    
     }
     public function register(){
        $data = $this->input->post();
        
        unset($data['add']);

      if ($this->form_validation->run() == FALSE)
      {
          $this->add();
          echo "error";
      }
      else
      {
            $this->DriverModel->insertUser($data);
       
          redirect('driver/index');
      }
  
        
}

  
    
    public function update($id){
        $data = $this->input->post();
        unset($data['submit']);
        $this->form_validation->set_rules('fname', 'First Name', 'required');
        $this->form_validation->set_rules('lname', 'Last Name ','required');
      if ($this->form_validation->run() == FALSE)
      {
           $this->edit('id');
          echo "error";
      }
      else
      {
        $this->Driver-> update($id,$data);
          redirect('driver/index');
      }
  
        }
    }
?>